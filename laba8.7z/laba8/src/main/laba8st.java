package main;

public class laba8st {
    private String stroka1;
    private String stroka2;
    private String stroka3;
    private String stroka4;

    public laba8st(){

    }

    public laba8st(String stroka1, String stroka2, String stroka3, String stroka4) {
        this.stroka1 = stroka1;
        this.stroka2 = stroka2;
        this.stroka3 = stroka3;
        this.stroka4 = stroka4;
    }

    public String getStroka1() {
        return stroka1;
    }

    public void setStroka1(String stroka1) {
        this.stroka1 = stroka1;
    }

    public String getStroka2() {
        return stroka2;
    }

    public void setStroka2(String stroka2) {
        this.stroka2 = stroka2;
    }

    public String getStroka3() {
        return stroka3;
    }

    public void setStroka3(String stroka3) {
        this.stroka3 = stroka3;
    }

    public String getStroka4() {
        return stroka4;
    }

    public void setStroka4(String stroka4) {
        this.stroka4 = stroka4;
    }
}
